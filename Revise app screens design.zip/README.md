
  # Revise app screens design

  This is a code bundle for Revise app screens design. The original project is available at https://www.figma.com/design/KcYdW7gusWJTLP8SgI7OgG/Revise-app-screens-design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  