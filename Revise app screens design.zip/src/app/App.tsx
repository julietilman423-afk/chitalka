import React, { useState } from "react";
import {
  ArrowRight,
  Settings,
  Home,
  Search,
  BookMarked,
  User,
  ChevronLeft,
  ChevronRight,
  Book,
} from "lucide-react";
import svgPaths from "@/imports/Main/svg-s5xagun89o";

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen =
  | "main"
  | "search"
  | "shelf"
  | "title"
  | "read"
  | "admin"
  | "create-title"
  | "create-episode";

type Tab = "main" | "search" | "shelf" | "admin";

// ─── Shared: list card ────────────────────────────────────────────────────────
// Pixel values taken directly from Figma imports:
//   card h=118, border=fcd773, rounded-24
//   cover: left=4 w=104 h=110 rounded-20
//   title: left=120 top=25, sub: left=120 top=49
//   right slot: left=324

// Card dimensions from Figma:
//   card h=118, border=1px fcd773, rounded-24
//   cover: ml=4px w=104 h=110 rounded-20
//   text starts at x=120 → gap after cover = 120-4-104 = 12px
//   right button: 12px margin from right border

function TitleCard({
  title,
  sub,
  coverShade = "#888",
  rightSlot,
}: {
  title: string;
  sub: string;
  coverShade?: string;
  rightSlot: React.ReactNode;
}) {
  return (
    <div
      className="flex items-center rounded-[24px] shrink-0 w-full overflow-hidden"
      style={{ background: "#121212", height: 118, border: "1px solid #fcd773" }}
    >
      {/* Cover — 4px from left border, matches Figma left=4 */}
      <div
        className="shrink-0 rounded-[20px]"
        style={{ background: coverShade, height: 110, width: 104, marginLeft: 4 }}
      />
      {/* Text — 12px gap after cover = Figma's left=120 (4+104+12) */}
      <div className="flex-1 min-w-0 flex flex-col justify-center" style={{ marginLeft: 12, gap: 8 }}>
        <p
          className="font-medium leading-none whitespace-nowrap overflow-hidden text-ellipsis"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          {title}
        </p>
        <p
          className="font-medium"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: 14,
            color: "#fbf4e5",
            lineHeight: 1.3,
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}
        >
          {sub}
        </p>
      </div>
      {/* Right slot — 12px from right border */}
      <div className="shrink-0" style={{ marginRight: 12, marginLeft: 8 }}>
        {rightSlot}
      </div>
    </div>
  );
}

/** Pink arrow button — replaces розовый квадрат (h=38 w=32 из Figma) */
function ArrowBtn({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center justify-center rounded-[8px] active:opacity-75"
      style={{ background: "#fcb7d9", height: 38, width: 32 }}
    >
      <ArrowRight size={15} color="#121212" strokeWidth={2.5} />
    </button>
  );
}

/** Green gear button — replaces зелёный квадрат (size=32 из Figma) */
function GearBtn({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      className="flex items-center justify-center rounded-[8px] active:opacity-75"
      style={{ background: "#98ab69", height: 32, width: 32 }}
    >
      <Settings size={14} color="#fff" strokeWidth={2} />
    </button>
  );
}

// ─── Screen: Main ─────────────────────────────────────────────────────────────
// Layout: flex-col, everything in normal flow to avoid overlaps.
// Preserves all Figma colors/sizes/fonts.

function MainScreen({ nav }: { nav: (s: Screen) => void }) {
  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Top bar — 24dp from top to logo, 44dp logo height, 12dp below */}
      <div className="flex items-center justify-between px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 12 }}>
        {/* Logo — replaces bg-[#b2cae9] синий прямоугольник */}
        <div
          className="flex items-center justify-center gap-1.5 rounded-[4px]"
          style={{ background: "#b2cae9", height: 44, width: 70 }}
        >
          <Book size={14} color="#121212" strokeWidth={2.5} />
          <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, fontWeight: 600, color: "#121212" }}>
            Читалка
          </span>
        </div>
        {/* Avatar */}
        <div style={{ width: 44, height: 44 }}>
          <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
            <path d={svgPaths.p3f990d00} fill="#B2CAE9" />
          </svg>
        </div>
      </div>

      {/* Featured cover card — bg-[#888] h-360 w-full-minus-32 rounded-24 */}
      <div className="px-4 shrink-0">
        <div
          className="relative overflow-hidden rounded-[24px] flex flex-col items-center justify-end"
          style={{ background: "#888", height: 360, paddingLeft: 85, paddingRight: 85, paddingBottom: 40 }}
        >
          <div className="relative w-full" style={{ height: 132 }}>
            <p
              className="absolute font-medium leading-none whitespace-nowrap"
              style={{ fontFamily: "'Inter', sans-serif", fontSize: 24, color: "#121212", left: "calc(50% - 105px)", top: 0 }}
            >
              Заголовок тайтла
            </p>
            <p
              className="absolute font-medium leading-none whitespace-nowrap"
              style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: "#fbf4e5", left: "calc(50% - 91px)", top: 32 }}
            >
              Теги, описывающие тайтл
            </p>
            <button
              onClick={() => nav("title")}
              className="absolute flex items-center justify-center rounded-[8px] active:opacity-85"
              style={{ background: "#fcd773", border: "2px solid #121212", height: 52, left: 21, top: 80, width: 169 }}
            >
              <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, fontWeight: 500, color: "#000" }}>
                Читать
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Новинки */}
      <div className="px-4 shrink-0" style={{ paddingTop: 20, paddingBottom: 12 }}>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          Новинки
        </p>
      </div>

      {/* 3 new covers: w=122/120/122 h=161 gap=8 */}
      <div className="flex gap-[8px] items-center px-4 shrink-0">
        <div className="bg-[#888] rounded-[24px]" style={{ height: 161, width: 122 }} />
        <div className="bg-[#888] rounded-[24px]" style={{ height: 161, width: 120 }} />
        <div className="bg-[#888] rounded-[24px]" style={{ height: 161, width: 122 }} />
      </div>
    </div>
  );
}

// ─── Screen: Search ───────────────────────────────────────────────────────────
// Flow layout preserving all Figma token values.

function SearchScreen() {
  const [q, setQ] = useState("");

  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-y-auto">
      {/* Библиотека — top=24 left=16 */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24 }}>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 24, color: "#fbf4e4" }}
        >
          Библиотека
        </p>
      </div>

      {/* Search bar — bg=#faf4e7, border=#121212, h=52, rounded-8 */}
      <div className="px-4 shrink-0" style={{ paddingTop: 16 }}>
        <div
          className="flex items-center rounded-[8px] overflow-hidden"
          style={{ background: "#faf4e7", border: "2px solid #121212", height: 52 }}
        >
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск"
            className="flex-1 bg-transparent outline-none"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 16,
              fontWeight: 500,
              color: "rgba(18,18,18,0.9)",
              paddingLeft: 16,
              border: "none",
            }}
          />
          <button
            onClick={() => {}}
            className="flex items-center justify-center shrink-0 active:opacity-60"
            style={{ width: 44, height: "100%", color: "#121212" }}
          >
            <Search size={20} strokeWidth={2} />
          </button>
        </div>
      </div>

      {/* Популярные */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 12 }}>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          Популярные
        </p>
      </div>

      {/* 3 popular covers */}
      <div className="flex gap-[8px] px-4 shrink-0">
        {[122, 120, 122].map((w, i) => (
          <div key={i} className="bg-[#888] rounded-[24px]" style={{ height: 161, width: w }} />
        ))}
      </div>

      {/* Жанры */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 12 }}>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          Жанры
        </p>
      </div>

      {/* 2×2 genre grid — gap-x=6 gap-y=16 из Figma */}
      <div
        className="grid grid-cols-2 px-4 shrink-0"
        style={{ gap: "16px 6px", paddingBottom: 24 }}
      >
        {["Фэнтези", "Экшн", "Романтика", "Ужасы"].map((g) => (
          <div
            key={g}
            className="bg-[#888] relative rounded-[24px]"
            style={{ height: 120 }}
          >
            <span
              className="absolute bottom-3 left-4 font-medium"
              style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#fbf4e5" }}
            >
              {g}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Screen: My Shelf ─────────────────────────────────────────────────────────
// Header fixed, list scrolls. Card dimensions from Figma: h=118 gap=16.

const SHELF_ITEMS = [
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
];

function ShelfScreen({ nav }: { nav: (s: Screen) => void }) {
  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Header — top=33 in Figma */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 24 }}>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 24, color: "#fbf4e4" }}
        >
          Моя полка
        </p>
      </div>

      {/* Scrollable list */}
      <div className="flex-1 overflow-y-auto px-4">
        <div className="flex flex-col gap-[16px] pb-4">
          {SHELF_ITEMS.map((item, i) => (
            <TitleCard
              key={i}
              title={item.title}
              sub={item.sub}
              coverShade="#888"
              rightSlot={<ArrowBtn onClick={() => nav("title")} />}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Screen: Title ────────────────────────────────────────────────────────────

const EPISODES = [
  { num: "Номер главы", date: "Дата публикации" },
  { num: "Номер главы", date: "Дата публикации" },
  { num: "Номер главы", date: "Дата публикации" },
  { num: "Номер главы", date: "Дата публикации" },
];

function TitleScreen({ nav, back }: { nav: (s: Screen) => void; back: () => void }) {
  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Header block — top=24 title, top=60 subtitle */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 20 }}>
        <div className="flex items-center gap-2 mb-2">
          <button onClick={back} className="active:opacity-70 shrink-0">
            <ChevronLeft size={22} color="#fbf4e5" />
          </button>
          <p
            className="font-medium leading-none whitespace-nowrap overflow-hidden text-ellipsis"
            style={{ fontFamily: "'Inter', sans-serif", fontSize: 22, color: "#fbf4e4" }}
          >
            Название открытого тайтла
          </p>
        </div>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5", paddingLeft: 30 }}
        >
          Количество эпизодов
        </p>
      </div>

      {/* Scrollable episodes list */}
      <div className="flex-1 overflow-y-auto px-4">
        <div className="flex flex-col gap-[16px] pb-4">
          {EPISODES.map((ep, i) => (
            <TitleCard
              key={i}
              title={ep.num}
              sub={ep.date}
              coverShade="#d9d9d9"
              rightSlot={<ArrowBtn onClick={() => nav("read")} />}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Screen: Read ─────────────────────────────────────────────────────────────
// Two pink nav buttons at bottom-right (from Figma: left=321 and left=364,
// both at bottom of frame). Converted to fixed bottom position.

function ReadScreen({ back }: { back: () => void }) {
  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2 px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 16 }}>
        <button onClick={back} className="active:opacity-70 shrink-0">
          <ChevronLeft size={22} color="#fbf4e5" />
        </button>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 24, color: "#fbf4e4" }}
        >
          Номер эпизода
        </p>
      </div>

      {/* Reading area — fills remaining space */}
      <div className="flex-1 bg-[#1e1e1e] mx-0" />

      {/* Nav buttons row — two pink arrows at bottom-right (Figma: left=321 and left=364) */}
      <div className="flex items-center justify-end gap-[11px] px-4 shrink-0" style={{ paddingTop: 12, paddingBottom: 16 }}>
        <button
          className="flex items-center justify-center rounded-[8px] active:opacity-75"
          style={{ background: "#fcb7d9", height: 38, width: 32 }}
        >
          <ChevronLeft size={16} color="#121212" strokeWidth={2.5} />
        </button>
        <button
          className="flex items-center justify-center rounded-[8px] active:opacity-75"
          style={{ background: "#fcb7d9", height: 38, width: 32 }}
        >
          <ChevronRight size={16} color="#121212" strokeWidth={2.5} />
        </button>
      </div>
    </div>
  );
}

// ─── Screen: Admin ────────────────────────────────────────────────────────────
// Header fixed, list scrolls, "Добавить тайтл" pinned at bottom.

const ADMIN_ITEMS = [
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
];

// Admin card — same flex layout as TitleCard, green gear button 12px from right border
function AdminCard({ title, sub, onGear }: { title: string; sub: string; onGear: () => void }) {
  return (
    <div
      className="flex items-center rounded-[24px] shrink-0 w-full overflow-hidden"
      style={{ background: "#121212", height: 118, border: "1px solid #fcd773" }}
    >
      {/* Cover */}
      <div
        className="shrink-0 rounded-[20px]"
        style={{ background: "#888", height: 110, width: 104, marginLeft: 4 }}
      />
      {/* Text */}
      <div className="flex-1 min-w-0 flex flex-col justify-center" style={{ marginLeft: 12, gap: 8 }}>
        <p
          className="font-medium leading-none whitespace-nowrap overflow-hidden text-ellipsis"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          {title}
        </p>
        <p
          className="font-medium"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: 14,
            color: "#fbf4e5",
            lineHeight: 1.3,
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}
        >
          {sub}
        </p>
      </div>
      {/* Gear button — 12px from right border */}
      <div className="shrink-0" style={{ marginRight: 12, marginLeft: 8 }}>
        <GearBtn onClick={onGear} />
      </div>
    </div>
  );
}

function AdminScreen({ nav }: { nav: (s: Screen) => void }) {
  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 16 }}>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 24, color: "#fbf4e4", marginBottom: 12 }}
        >
          Кабинет автора
        </p>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          Загруженные тайтлы
        </p>
      </div>

      {/* Scrollable list */}
      <div className="flex-1 overflow-y-auto px-4">
        <div className="flex flex-col gap-[16px]">
          {ADMIN_ITEMS.map((item, i) => (
            <AdminCard key={i} title={item.title} sub={item.sub} onGear={() => nav("create-title")} />
          ))}
        </div>
        <div style={{ height: 16 }} />
      </div>

      {/* "Добавить тайтл" — pinned at bottom, bg=#fcd773, h=52, rounded-8, border-2 #121212 */}
      <div className="px-4 shrink-0" style={{ paddingTop: 12, paddingBottom: 16 }}>
        <button
          onClick={() => nav("create-title")}
          className="relative overflow-hidden rounded-[8px] w-full active:opacity-85"
          style={{ background: "#fcd773", border: "2px solid #121212", height: 52 }}
        >
          <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, fontWeight: 500, color: "#000" }}>
            Добавить тайтл
          </span>
        </button>
      </div>
    </div>
  );
}

// ─── Screen: Create Title (wireframe) ─────────────────────────────────────────

function CreateTitleScreen({ back }: { back: () => void }) {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [tags, setTags] = useState("");

  const inp: React.CSSProperties = {
    background: "#EBEBEB", borderRadius: 10, border: "none", outline: "none",
    color: "#1C1C1E", fontSize: 14, fontFamily: "'Inter', sans-serif",
    width: "100%", padding: "12px 16px", boxSizing: "border-box",
  };

  return (
    <div className="size-full overflow-y-auto" style={{ background: "#F5F5F7" }}>
      <div className="px-4 pb-8 flex flex-col gap-3" style={{ paddingTop: 24 }}>
        <button onClick={back} className="self-start active:opacity-70">
          <ChevronLeft size={22} color="#1C1C1E" />
        </button>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 20, fontWeight: 700, color: "#1C1C1E", marginBottom: 8 }}>
          Создать тайтл
        </p>
        <div style={{ background: "#DDDDE0", borderRadius: 14, border: "2px dashed #B8B8BE", height: 160 }}
          className="flex flex-col items-center justify-center">
          <p style={{ color: "#A0A0A8", fontSize: 12 }}>Загрузить обложку</p>
        </div>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Название тайтла" style={inp} />
        <textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Описание" rows={3}
          style={{ ...inp, resize: "none" }} />
        <input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="Теги, жанры" style={inp} />
        <button style={{ background: "#fcd773", borderRadius: 10, padding: "14px", border: "2px solid #121212" }}
          className="font-medium text-black text-sm">
          Создать
        </button>
        <button onClick={back} style={{ borderRadius: 10, border: "1.5px solid #DDDDE0", padding: "14px" }}
          className="text-sm font-medium text-gray-600">
          Отмена
        </button>
      </div>
    </div>
  );
}

// ─── Screen: Create Episode (wireframe) ───────────────────────────────────────

function CreateEpisodeScreen({ back }: { back: () => void }) {
  const [num, setNum] = useState("");
  const [name, setName] = useState("");

  const inp: React.CSSProperties = {
    background: "#EBEBEB", borderRadius: 10, border: "none", outline: "none",
    color: "#1C1C1E", fontSize: 14, fontFamily: "'Inter', sans-serif",
    width: "100%", padding: "12px 16px", boxSizing: "border-box",
  };

  return (
    <div className="size-full overflow-y-auto" style={{ background: "#F5F5F7" }}>
      <div className="px-4 pb-8 flex flex-col gap-3" style={{ paddingTop: 24 }}>
        <button onClick={back} className="self-start active:opacity-70">
          <ChevronLeft size={22} color="#1C1C1E" />
        </button>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 20, fontWeight: 700, color: "#1C1C1E", marginBottom: 8 }}>
          Создать эпизод
        </p>
        <input value={num} onChange={(e) => setNum(e.target.value)} placeholder="Номер главы" style={inp} />
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Название эпизода" style={inp} />
        <div style={{ background: "#DDDDE0", borderRadius: 12, border: "2px dashed #B8B8BE", height: 80 }}
          className="flex flex-col items-center justify-center">
          <p style={{ color: "#A0A0A8", fontSize: 11 }}>Добавить страницы</p>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[0, 1, 2].map((i) => (
            <div key={i} style={{ background: "#DDDDE0", borderRadius: 8, height: 80 }} />
          ))}
        </div>
        <button style={{ background: "#fcd773", borderRadius: 10, padding: "14px", border: "2px solid #121212" }}
          className="font-medium text-black text-sm">
          Сохранить
        </button>
        <button onClick={back} style={{ borderRadius: 10, border: "1.5px solid #DDDDE0", padding: "14px" }}
          className="text-sm font-medium text-gray-600">
          Отмена
        </button>
      </div>
    </div>
  );
}

// ─── Bottom Nav ───────────────────────────────────────────────────────────────

function BottomNav({ tab, setTab }: { tab: Tab; setTab: (t: Tab) => void }) {
  const items: { id: Tab; icon: React.ReactNode; label: string }[] = [
    { id: "main",   icon: <Home size={22} />,       label: "Главная" },
    { id: "search", icon: <Search size={22} />,     label: "Библиотека" },
    { id: "shelf",  icon: <BookMarked size={22} />, label: "Полка" },
    { id: "admin",  icon: <User size={22} />,       label: "Кабинет" },
  ];

  return (
    <div
      className="flex items-center justify-around shrink-0"
      style={{ background: "#1a1a1a", borderTop: "1px solid #2a2a2a", paddingTop: 10, paddingBottom: 10 }}
    >
      {items.map((it) => (
        <button
          key={it.id}
          onClick={() => setTab(it.id)}
          className="flex flex-col items-center gap-0.5 px-3 active:opacity-70"
          style={{ color: tab === it.id ? "#fcd773" : "#555" }}
        >
          {it.icon}
          <span style={{ fontSize: 10, fontWeight: 500, fontFamily: "'Inter', sans-serif" }}>
            {it.label}
          </span>
        </button>
      ))}
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("main");
  const [tab, setTab]       = useState<Tab>("main");
  const [stack, setStack]   = useState<Screen[]>([]);

  const nav = (s: Screen) => {
    setStack((p) => [...p, screen]);
    setScreen(s);
  };

  const back = () => {
    if (!stack.length) return;
    const prev = stack[stack.length - 1];
    setStack((p) => p.slice(0, -1));
    setScreen(prev);
  };

  const switchTab = (t: Tab) => {
    setTab(t);
    setStack([]);
    const map: Record<Tab, Screen> = { main: "main", search: "search", shelf: "shelf", admin: "admin" };
    setScreen(map[t]);
  };

  const isTabScreen = ["main", "search", "shelf", "admin"].includes(screen);

  const tabOf: Record<Screen, Tab> = {
    main: "main", search: "search", shelf: "shelf", admin: "admin",
    title: "main", read: "main", "create-title": "admin", "create-episode": "admin",
  };

  const renderScreen = () => {
    switch (screen) {
      case "main":           return <MainScreen nav={nav} />;
      case "search":         return <SearchScreen />;
      case "shelf":          return <ShelfScreen nav={nav} />;
      case "title":          return <TitleScreen nav={nav} back={back} />;
      case "read":           return <ReadScreen back={back} />;
      case "admin":          return <AdminScreen nav={nav} />;
      case "create-title":   return <CreateTitleScreen back={back} />;
      case "create-episode": return <CreateEpisodeScreen back={back} />;
    }
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center"
      style={{ background: "#121212" }}
    >
      {/* Phone frame — 412px matching Figma canvas width */}
      <div
        style={{
          width:         "min(412px, 100vw)",
          height:        "min(917px, 100dvh)",
          display:       "flex",
          flexDirection: "column",
          overflow:      "hidden",
          borderRadius:  "clamp(0px, 4vw, 44px)",
          boxShadow:     "0 40px 100px rgba(0,0,0,0.8)",
          fontFamily:    "'Inter', system-ui, sans-serif",
        }}
      >
        <div className="flex-1 overflow-hidden relative">
          {renderScreen()}
        </div>

        {isTabScreen && (
          <BottomNav tab={tabOf[screen]} setTab={switchTab} />
        )}
      </div>
    </div>
  );
}
