import React, { useState, useEffect } from "react";
import {
  ArrowRight,
  Settings,
  Home,
  Search,
  BookMarked,
  User,
  ChevronLeft,
  ChevronRight,
  Book,
  GripVertical,
  Trash2,
  ImagePlus,
  Plus,
} from "lucide-react";
import svgPaths from "@/imports/Main/svg-s5xagun89o";

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen =
  | "auth"
  | "main"
  | "search"
  | "shelf"
  | "title"
  | "read"
  | "admin"
  | "title-settings"
  | "edit-chapters"
  | "edit-chapter-images"
  | "create-title"
  | "create-episode";

type Tab = "main" | "search" | "shelf" | "admin";
type Role = "reader" | "author";

// ─── Shared: list card ────────────────────────────────────────────────────────
// Pixel values taken directly from Figma imports:
//   card h=118, border=fcd773, rounded-24
//   cover: left=4 w=104 h=110 rounded-20
//   title: left=120 top=25, sub: left=120 top=49
//   right slot: left=324

// Card dimensions from Figma:
//   card h=118, border=1px fcd773, rounded-24
//   cover: ml=4px w=104 h=110 rounded-20
//   text starts at x=120 → gap after cover = 120-4-104 = 12px
//   right button: 12px margin from right border

function TitleCard({
  title,
  sub,
  coverShade = "#888",
  rightSlot,
}: {
  title: string;
  sub: string;
  coverShade?: string;
  rightSlot: React.ReactNode;
}) {
  return (
    <div
      className="flex items-center rounded-[24px] shrink-0 w-full overflow-hidden"
      style={{ background: "#121212", height: 118, border: "1px solid #fcd773" }}
    >
      {/* Cover — 4px from left border, matches Figma left=4 */}
      <div
        className="shrink-0 rounded-[20px]"
        style={{ background: coverShade, height: 110, width: 104, marginLeft: 4 }}
      />
      {/* Text — 12px gap after cover = Figma's left=120 (4+104+12) */}
      <div className="flex-1 min-w-0 flex flex-col justify-center" style={{ marginLeft: 12, gap: 8 }}>
        <p
          className="font-medium leading-none whitespace-nowrap overflow-hidden text-ellipsis"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          {title}
        </p>
        <p
          className="font-medium"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: 14,
            color: "#fbf4e5",
            lineHeight: 1.3,
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}
        >
          {sub}
        </p>
      </div>
      {/* Right slot — 12px from right border */}
      <div className="shrink-0" style={{ marginRight: 12, marginLeft: 8 }}>
        {rightSlot}
      </div>
    </div>
  );
}

/** Pink arrow button — replaces розовый квадрат (h=38 w=32 из Figma) */
function ArrowBtn({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center justify-center rounded-[8px] active:opacity-75"
      style={{ background: "#fcb7d9", height: 38, width: 32 }}
    >
      <ArrowRight size={15} color="#121212" strokeWidth={2.5} />
    </button>
  );
}

/** Green gear button — replaces зелёный квадрат (size=32 из Figma) */
function GearBtn({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      className="flex items-center justify-center rounded-[8px] active:opacity-75"
      style={{ background: "#98ab69", height: 32, width: 32 }}
    >
      <Settings size={14} color="#fff" strokeWidth={2} />
    </button>
  );
}

// ─── Screen: Main ─────────────────────────────────────────────────────────────
// Layout: flex-col, everything in normal flow to avoid overlaps.
// Preserves all Figma colors/sizes/fonts.

// ─── Screen: Auth ─────────────────────────────────────────────────────────────

function AuthScreen({ onLogin }: { onLogin: (role: Role) => void }) {
  return (
    <div
      className="size-full flex flex-col"
      style={{ background: "#121212" }}
    >
      {/* Logo area */}
      <div className="flex-1 flex flex-col items-center justify-center gap-4">
        <div
          className="flex items-center gap-2 rounded-[12px] px-5"
          style={{ background: "#b2cae9", height: 56 }}
        >
          <Book size={20} color="#121212" strokeWidth={2.5} />
          <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 20, fontWeight: 700, color: "#121212" }}>
            Читалка
          </span>
        </div>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: "#8E8E93" }}>
          Выберите, как вы хотите войти
        </p>
      </div>

      {/* Role cards */}
      <div className="px-4 flex flex-col gap-3" style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 40px)" }}>
        {/* Reader */}
        <button
          onClick={() => onLogin("reader")}
          className="w-full flex items-center gap-4 rounded-[20px] active:opacity-85"
          style={{ background: "#1e1e1e", border: "1px solid #fcd773", padding: "20px 20px" }}
        >
          <div className="flex items-center justify-center rounded-[14px] shrink-0"
            style={{ background: "#2a2a2a", width: 52, height: 52 }}>
            <BookMarked size={24} color="#fcd773" strokeWidth={1.8} />
          </div>
          <div className="text-left flex-1">
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 17, fontWeight: 600, color: "#fbf4e5", marginBottom: 4 }}>
              Читатель
            </p>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#8E8E93", lineHeight: 1.4 }}>
              Главная, библиотека и полка
            </p>
          </div>
          <ChevronRight size={18} color="#555" />
        </button>

        {/* Author */}
        <button
          onClick={() => onLogin("author")}
          className="w-full flex items-center gap-4 rounded-[20px] active:opacity-85"
          style={{ background: "#1e1e1e", border: "1px solid #98ab69", padding: "20px 20px" }}
        >
          <div className="flex items-center justify-center rounded-[14px] shrink-0"
            style={{ background: "#2a2a2a", width: 52, height: 52 }}>
            <User size={24} color="#98ab69" strokeWidth={1.8} />
          </div>
          <div className="text-left flex-1">
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 17, fontWeight: 600, color: "#fbf4e5", marginBottom: 4 }}>
              Автор
            </p>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#8E8E93", lineHeight: 1.4 }}>
              Главная, библиотека, полка и кабинет
            </p>
          </div>
          <ChevronRight size={18} color="#555" />
        </button>
      </div>
    </div>
  );
}

// ─── Screen: Main ─────────────────────────────────────────────────────────────

function MainScreen({ nav }: { nav: (s: Screen) => void }) {
  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-y-auto">
      {/* Top bar — 24dp from top */}
      <div className="flex items-center justify-between px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 12 }}>
        {/* Logo — auto width to avoid clipping */}
        <div
          className="flex items-center gap-1.5 rounded-[4px] px-3"
          style={{ background: "#b2cae9", height: 44 }}
        >
          <Book size={14} color="#121212" strokeWidth={2.5} />
          <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, fontWeight: 700, color: "#121212", whiteSpace: "nowrap" }}>
            Читалка
          </span>
        </div>
        {/* Avatar */}
        <div style={{ width: 44, height: 44, flexShrink: 0 }}>
          <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
            <path d={svgPaths.p3f990d00} fill="#B2CAE9" />
          </svg>
        </div>
      </div>

      {/* Featured cover card */}
      <div className="px-4 shrink-0">
        <div
          className="rounded-[24px] overflow-hidden flex flex-col justify-end"
          style={{ background: "#888", height: 360, padding: "0 16px 28px" }}
        >
          {/* Title + tags centred over the button */}
          <p
            className="font-medium leading-none text-center"
            style={{ fontFamily: "'Inter', sans-serif", fontSize: 24, color: "#121212", marginBottom: 8 }}
          >
            Заголовок тайтла
          </p>
          <p
            className="font-medium leading-none text-center"
            style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: "#fbf4e5", marginBottom: 20 }}
          >
            Теги, описывающие тайтл
          </p>
          {/* Читать button — full width minus card padding */}
          <button
            onClick={() => nav("title")}
            className="flex items-center justify-center rounded-[8px] active:opacity-85 w-full"
            style={{ background: "#fcd773", border: "2px solid #121212", height: 52 }}
          >
            <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, fontWeight: 500, color: "#000" }}>
              Читать
            </span>
          </button>
        </div>
      </div>

      {/* Новинки */}
      <div className="px-4 shrink-0" style={{ paddingTop: 20, paddingBottom: 12 }}>
        <p
          className="font-medium leading-none"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          Новинки
        </p>
      </div>

      {/* 3 new covers */}
      <div className="flex gap-[8px] px-4 shrink-0" style={{ paddingBottom: 24 }}>
        <div className="bg-[#888] rounded-[24px]" style={{ height: 161, flex: "1 1 0" }} />
        <div className="bg-[#888] rounded-[24px]" style={{ height: 161, flex: "1 1 0" }} />
        <div className="bg-[#888] rounded-[24px]" style={{ height: 161, flex: "1 1 0" }} />
      </div>
    </div>
  );
}

// ─── Screen: Search ───────────────────────────────────────────────────────────
// Flow layout preserving all Figma token values.

function SearchScreen() {
  const [q, setQ] = useState("");

  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-y-auto">
      {/* Библиотека — top=24 left=16 */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24 }}>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 24, color: "#fbf4e4" }}
        >
          Библиотека
        </p>
      </div>

      {/* Search bar — bg=#faf4e7, border=#121212, h=52, rounded-8 */}
      <div className="px-4 shrink-0" style={{ paddingTop: 16 }}>
        <div
          className="flex items-center rounded-[8px] overflow-hidden"
          style={{ background: "#faf4e7", border: "2px solid #121212", height: 52 }}
        >
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск"
            className="flex-1 bg-transparent outline-none"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 16,
              fontWeight: 500,
              color: "rgba(18,18,18,0.9)",
              paddingLeft: 16,
              border: "none",
            }}
          />
          <button
            onClick={() => {}}
            className="flex items-center justify-center shrink-0 active:opacity-60"
            style={{ width: 44, height: "100%", color: "#121212" }}
          >
            <Search size={20} strokeWidth={2} />
          </button>
        </div>
      </div>

      {/* Популярные */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 12 }}>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          Популярные
        </p>
      </div>

      {/* 3 popular covers */}
      <div className="flex gap-[8px] px-4 shrink-0">
        {[122, 120, 122].map((w, i) => (
          <div key={i} className="bg-[#888] rounded-[24px]" style={{ height: 161, width: w }} />
        ))}
      </div>

      {/* Жанры */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 12 }}>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          Жанры
        </p>
      </div>

      {/* 2×2 genre grid — gap-x=6 gap-y=16 из Figma */}
      <div
        className="grid grid-cols-2 px-4 shrink-0"
        style={{ gap: "16px 6px", paddingBottom: 24 }}
      >
        {["Фэнтези", "Экшн", "Романтика", "Ужасы"].map((g) => (
          <div
            key={g}
            className="bg-[#888] relative rounded-[24px]"
            style={{ height: 120 }}
          >
            <span
              className="absolute bottom-3 left-4 font-medium"
              style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#fbf4e5" }}
            >
              {g}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Screen: My Shelf ─────────────────────────────────────────────────────────
// Header fixed, list scrolls. Card dimensions from Figma: h=118 gap=16.

const SHELF_ITEMS = [
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
];

function ShelfScreen({ nav }: { nav: (s: Screen) => void }) {
  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Header — top=33 in Figma */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 24 }}>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 24, color: "#fbf4e4" }}
        >
          Моя полка
        </p>
      </div>

      {/* Scrollable list */}
      <div className="flex-1 overflow-y-auto px-4">
        <div className="flex flex-col gap-[16px] pb-4">
          {SHELF_ITEMS.map((item, i) => (
            <TitleCard
              key={i}
              title={item.title}
              sub={item.sub}
              coverShade="#888"
              rightSlot={<ArrowBtn onClick={() => nav("title")} />}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Screen: Title ────────────────────────────────────────────────────────────

const EPISODES = [
  { num: "Номер главы", date: "Дата публикации" },
  { num: "Номер главы", date: "Дата публикации" },
  { num: "Номер главы", date: "Дата публикации" },
  { num: "Номер главы", date: "Дата публикации" },
];

function TitleScreen({ nav, back }: { nav: (s: Screen) => void; back: () => void }) {
  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Header block — top=24 title, top=60 subtitle */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 20 }}>
        <div className="flex items-center gap-2 mb-2">
          <button onClick={back} className="active:opacity-70 shrink-0">
            <ChevronLeft size={22} color="#fbf4e5" />
          </button>
          <p
            className="font-medium leading-none whitespace-nowrap overflow-hidden text-ellipsis"
            style={{ fontFamily: "'Inter', sans-serif", fontSize: 22, color: "#fbf4e4" }}
          >
            Название открытого тайтла
          </p>
        </div>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5", paddingLeft: 30 }}
        >
          Количество эпизодов
        </p>
      </div>

      {/* Scrollable episodes list */}
      <div className="flex-1 overflow-y-auto px-4">
        <div className="flex flex-col gap-[16px]" style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 24px)" }}>
          {EPISODES.map((ep, i) => (
            <TitleCard
              key={i}
              title={ep.num}
              sub={ep.date}
              coverShade="#d9d9d9"
              rightSlot={<ArrowBtn onClick={() => nav("read")} />}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Screen: Read ─────────────────────────────────────────────────────────────
// Two pink nav buttons at bottom-right (from Figma: left=321 and left=364,
// both at bottom of frame). Converted to fixed bottom position.

function ReadScreen({ back }: { back: () => void }) {
  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2 px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 16 }}>
        <button onClick={back} className="active:opacity-70 shrink-0">
          <ChevronLeft size={22} color="#fbf4e5" />
        </button>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 24, color: "#fbf4e4" }}
        >
          Номер эпизода
        </p>
      </div>

      {/* Reading area — fills remaining space */}
      <div className="flex-1 bg-[#1e1e1e] mx-0" />

      {/* Nav buttons row — two pink arrows at bottom-right */}
      <div className="flex items-center justify-end gap-[11px] px-4 shrink-0" style={{ paddingTop: 12, paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 16px)" }}>
        <button
          className="flex items-center justify-center rounded-[8px] active:opacity-75"
          style={{ background: "#fcb7d9", height: 38, width: 32 }}
        >
          <ChevronLeft size={16} color="#121212" strokeWidth={2.5} />
        </button>
        <button
          className="flex items-center justify-center rounded-[8px] active:opacity-75"
          style={{ background: "#fcb7d9", height: 38, width: 32 }}
        >
          <ChevronRight size={16} color="#121212" strokeWidth={2.5} />
        </button>
      </div>
    </div>
  );
}

// ─── Screen: Admin ────────────────────────────────────────────────────────────
// Header fixed, list scrolls, "Добавить тайтл" pinned at bottom.

const ADMIN_ITEMS = [
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
  { title: "Название тайтла", sub: "Номер последней прочитанной главы" },
];

// Admin card — same flex layout as TitleCard, green gear button 12px from right border
function AdminCard({ title, sub, onGear }: { title: string; sub: string; onGear: () => void }) {
  return (
    <div
      className="flex items-center rounded-[24px] shrink-0 w-full overflow-hidden"
      style={{ background: "#121212", height: 118, border: "1px solid #fcd773" }}
    >
      {/* Cover */}
      <div
        className="shrink-0 rounded-[20px]"
        style={{ background: "#888", height: 110, width: 104, marginLeft: 4 }}
      />
      {/* Text */}
      <div className="flex-1 min-w-0 flex flex-col justify-center" style={{ marginLeft: 12, gap: 8 }}>
        <p
          className="font-medium leading-none whitespace-nowrap overflow-hidden text-ellipsis"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          {title}
        </p>
        <p
          className="font-medium"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: 14,
            color: "#fbf4e5",
            lineHeight: 1.3,
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}
        >
          {sub}
        </p>
      </div>
      {/* Gear button — 12px from right border */}
      <div className="shrink-0" style={{ marginRight: 12, marginLeft: 8 }}>
        <GearBtn onClick={onGear} />
      </div>
    </div>
  );
}

function AdminScreen({ nav }: { nav: (s: Screen) => void }) {
  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 16 }}>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 24, color: "#fbf4e4", marginBottom: 12 }}
        >
          Кабинет автора
        </p>
        <p
          className="font-medium leading-none whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5" }}
        >
          Загруженные тайтлы
        </p>
      </div>

      {/* Scrollable list */}
      <div className="flex-1 overflow-y-auto px-4">
        <div className="flex flex-col gap-[16px]">
          {ADMIN_ITEMS.map((item, i) => (
            <AdminCard key={i} title={item.title} sub={item.sub} onGear={() => nav("title-settings")} />
          ))}
        </div>
        <div style={{ height: 16 }} />
      </div>

      {/* "Добавить тайтл" — pinned at bottom */}
      <div className="px-4 shrink-0" style={{ paddingTop: 12, paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 16px)" }}>
        <button
          onClick={() => nav("create-title")}
          className="relative overflow-hidden rounded-[8px] w-full active:opacity-85"
          style={{ background: "#fcd773", border: "2px solid #121212", height: 52 }}
        >
          <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, fontWeight: 500, color: "#000" }}>
            Добавить тайтл
          </span>
        </button>
      </div>
    </div>
  );
}

// ─── Screen: Create Title (wireframe) ─────────────────────────────────────────

// ─── Screen: Title Settings ───────────────────────────────────────────────────

function TitleSettingsScreen({ nav, back }: { nav: (s: Screen) => void; back: () => void }) {
  const inp: React.CSSProperties = {
    background: "#EBEBEB", borderRadius: 10, border: "none", outline: "none",
    color: "#1C1C1E", fontSize: 14, fontFamily: "'Inter', sans-serif",
    width: "100%", padding: "12px 16px", boxSizing: "border-box",
  };

  const rows: { label: string; icon: React.ReactNode; action: () => void; danger?: boolean }[] = [
    {
      label: "Редактировать главы",
      icon: <BookMarked size={18} strokeWidth={2} />,
      action: () => nav("edit-chapters"),
    },
    {
      label: "Изменить обложку",
      icon: (
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
          <rect x="1" y="3" width="16" height="12" rx="2" stroke="currentColor" strokeWidth="2" />
          <circle cx="6" cy="7" r="1.5" fill="currentColor" />
          <path d="M1 13l4-4 3 3 2-2 4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ),
      action: () => {},
    },
    {
      label: "Изменить название и описание",
      icon: <Settings size={18} strokeWidth={2} />,
      action: () => nav("create-title"),
    },
    {
      label: "Управление доступом",
      icon: (
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
          <circle cx="9" cy="7" r="3" stroke="currentColor" strokeWidth="2" />
          <path d="M2 16c0-3.314 3.134-6 7-6s7 2.686 7 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      ),
      action: () => {},
    },
    {
      label: "Удалить тайтл",
      icon: (
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
          <path d="M3 5h12M7 5V3h4v2M6 5l1 10h4l1-10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ),
      action: () => {},
      danger: true,
    },
  ];

  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 20 }}>
        <button onClick={back} className="active:opacity-70 shrink-0">
          <ChevronLeft size={22} color="#fbf4e5" />
        </button>
        <p className="font-medium leading-none"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 22, color: "#fbf4e4" }}>
          Настройка тайтла
        </p>
      </div>

      {/* Cover preview */}
      <div className="px-4 shrink-0" style={{ marginBottom: 20 }}>
        <div className="flex items-center gap-4">
          <div style={{ background: "#888", borderRadius: 16, width: 80, height: 80, flexShrink: 0 }} />
          <div>
            <p className="font-medium" style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "#fbf4e5", marginBottom: 4 }}>
              Название тайтла
            </p>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#8E8E93" }}>
              4 главы · опубликован
            </p>
          </div>
        </div>
      </div>

      {/* Action rows */}
      <div className="flex-1 overflow-y-auto px-4">
        <div className="flex flex-col" style={{ gap: 2, paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 24px)" }}>
          {rows.map((row, i) => (
            <button
              key={i}
              onClick={row.action}
              className="flex items-center gap-4 w-full active:opacity-70 rounded-[16px]"
              style={{
                background: "#1e1e1e",
                padding: "16px",
                border: "none",
                color: row.danger ? "#FF453A" : "#fbf4e5",
                marginBottom: i === rows.length - 2 ? 16 : 0,
              }}
            >
              <span style={{ color: row.danger ? "#FF453A" : "#8E8E93", flexShrink: 0 }}>
                {row.icon}
              </span>
              <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 15, fontWeight: 500, flex: 1, textAlign: "left" }}>
                {row.label}
              </span>
              {!row.danger && <ChevronRight size={16} color="#555" />}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Screen: Edit Chapters ────────────────────────────────────────────────────

interface ChapterItem {
  id: number;
  num: string;
  pages: number;
}

function EditChaptersScreen({ nav, back }: { nav: (s: Screen) => void; back: () => void }) {
  const [chapters, setChapters] = useState<ChapterItem[]>([
    { id: 1, num: "Глава 1", pages: 18 },
    { id: 2, num: "Глава 2", pages: 24 },
    { id: 3, num: "Глава 3", pages: 21 },
    { id: 4, num: "Глава 4", pages: 16 },
  ]);

  const moveUp = (i: number) => {
    if (i === 0) return;
    setChapters((prev) => {
      const next = [...prev];
      [next[i - 1], next[i]] = [next[i], next[i - 1]];
      return next;
    });
  };

  const moveDown = (i: number) => {
    setChapters((prev) => {
      if (i === prev.length - 1) return prev;
      const next = [...prev];
      [next[i], next[i + 1]] = [next[i + 1], next[i]];
      return next;
    });
  };

  const remove = (id: number) =>
    setChapters((prev) => prev.filter((c) => c.id !== id));

  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 20 }}>
        <button onClick={back} className="active:opacity-70 shrink-0">
          <ChevronLeft size={22} color="#fbf4e5" />
        </button>
        <p className="font-medium leading-none flex-1"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 22, color: "#fbf4e4" }}>
          Редактировать главы
        </p>
        {/* Add chapter */}
        <button
          onClick={() => nav("create-episode")}
          className="flex items-center gap-1.5 rounded-[8px] active:opacity-75 shrink-0"
          style={{ background: "#fcd773", border: "2px solid #121212", padding: "6px 12px" }}
        >
          <Plus size={14} color="#121212" strokeWidth={2.5} />
          <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, fontWeight: 600, color: "#121212" }}>
            Добавить
          </span>
        </button>
      </div>

      {/* Chapter list */}
      <div className="flex-1 overflow-y-auto px-4">
        <div className="flex flex-col gap-3" style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 24px)" }}>
          {chapters.map((ch, i) => (
            <div
              key={ch.id}
              className="flex items-center gap-3 rounded-[16px] overflow-hidden"
              style={{ background: "#1e1e1e", border: "1px solid #fcd773", padding: "12px" }}
            >
              {/* Cover thumb */}
              <div style={{ background: "#888", width: 48, height: 48, borderRadius: 10, flexShrink: 0 }} />

              {/* Info */}
              <div className="flex-1 min-w-0">
                <p className="font-medium leading-none"
                  style={{ fontFamily: "'Inter', sans-serif", fontSize: 15, color: "#fbf4e5", marginBottom: 4 }}>
                  {ch.num}
                </p>
                <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#8E8E93" }}>
                  {ch.pages} страниц
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 shrink-0">
                {/* Replace images */}
                <button
                  onClick={() => nav("edit-chapter-images")}
                  className="flex items-center justify-center rounded-[8px] active:opacity-75"
                  style={{ background: "#98ab69", width: 32, height: 32 }}
                  title="Заменить изображения"
                >
                  <ImagePlus size={14} color="#fff" strokeWidth={2} />
                </button>

                {/* Reorder */}
                <div className="flex flex-col gap-0.5">
                  <button
                    onClick={() => moveUp(i)}
                    disabled={i === 0}
                    className="flex items-center justify-center rounded-[6px] active:opacity-75"
                    style={{ background: i === 0 ? "#2a2a2a" : "#3a3a3c", width: 28, height: 14 }}
                  >
                    <ChevronLeft size={10} color={i === 0 ? "#555" : "#fbf4e5"} style={{ transform: "rotate(90deg)" }} />
                  </button>
                  <button
                    onClick={() => moveDown(i)}
                    disabled={i === chapters.length - 1}
                    className="flex items-center justify-center rounded-[6px] active:opacity-75"
                    style={{ background: i === chapters.length - 1 ? "#2a2a2a" : "#3a3a3c", width: 28, height: 14 }}
                  >
                    <ChevronRight size={10} color={i === chapters.length - 1 ? "#555" : "#fbf4e5"} style={{ transform: "rotate(90deg)" }} />
                  </button>
                </div>

                {/* Delete */}
                <button
                  onClick={() => remove(ch.id)}
                  className="flex items-center justify-center rounded-[8px] active:opacity-75"
                  style={{ background: "#3a1a1a", width: 32, height: 32 }}
                >
                  <Trash2 size={14} color="#FF453A" strokeWidth={2} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Screen: Edit Chapter Images ──────────────────────────────────────────────

function EditChapterImagesScreen({ back }: { back: () => void }) {
  const [pages, setPages] = useState([1, 2, 3, 4, 5, 6]);

  const removePage = (i: number) =>
    setPages((prev) => prev.filter((_, idx) => idx !== i));

  return (
    <div className="bg-[#121212] size-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 shrink-0" style={{ paddingTop: 24, paddingBottom: 8 }}>
        <button onClick={back} className="active:opacity-70 shrink-0">
          <ChevronLeft size={22} color="#fbf4e5" />
        </button>
        <p className="font-medium leading-none flex-1"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: 22, color: "#fbf4e4" }}>
          Страницы главы
        </p>
      </div>
      <p className="px-4 shrink-0" style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#8E8E93", paddingBottom: 16 }}>
        Нажмите на страницу, чтобы заменить изображение
      </p>

      {/* Pages grid */}
      <div className="flex-1 overflow-y-auto px-4">
        <div className="grid grid-cols-3 gap-3" style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 100px)" }}>
          {pages.map((_, i) => (
            <div key={i} className="relative">
              {/* Page thumbnail */}
              <label
                htmlFor={`page-${i}`}
                style={{ background: "#d9d9d9", borderRadius: 10, aspectRatio: "2/3", display: "block", cursor: "pointer", position: "relative", overflow: "hidden" }}
              >
                <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 active:opacity-100"
                  style={{ background: "rgba(0,0,0,0.4)", transition: "opacity 0.15s" }}>
                  <ImagePlus size={20} color="#fff" />
                </div>
                <span className="absolute bottom-1 right-2"
                  style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: "#555", fontWeight: 600 }}>
                  {i + 1}
                </span>
                <input id={`page-${i}`} type="file" accept="image/*" style={{ display: "none" }} />
              </label>

              {/* Delete page */}
              <button
                onClick={() => removePage(i)}
                className="absolute flex items-center justify-center rounded-full active:opacity-75"
                style={{ background: "#FF453A", width: 20, height: 20, top: 6, right: 6, border: "2px solid #121212" }}
              >
                <Trash2 size={9} color="#fff" strokeWidth={3} />
              </button>
            </div>
          ))}

          {/* Add page */}
          <label
            htmlFor="add-page"
            style={{ background: "#1e1e1e", borderRadius: 10, aspectRatio: "2/3", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6, cursor: "pointer", border: "2px dashed #3a3a3c" }}
          >
            <Plus size={22} color="#555" />
            <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: "#555" }}>Добавить</span>
            <input id="add-page" type="file" accept="image/*" multiple style={{ display: "none" }}
              onChange={(e) => {
                if (e.target.files) setPages((p) => [...p, ...Array.from(e.target.files!).map((_, j) => p.length + j + 1)]);
              }}
            />
          </label>
        </div>
      </div>

      {/* Save */}
      <div className="px-4 shrink-0" style={{ paddingTop: 12, paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 16px)" }}>
        <button
          className="w-full flex items-center justify-center rounded-[10px] active:opacity-85"
          style={{ background: "#fcd773", border: "2px solid #121212", height: 52 }}
        >
          <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, fontWeight: 600, color: "#121212" }}>
            Сохранить
          </span>
        </button>
      </div>
    </div>
  );
}

// ─── Screen: Create Title ─────────────────────────────────────────────────────

function CreateTitleScreen({ back }: { back: () => void }) {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [tags, setTags] = useState("");
  const [scrollDir, setScrollDir] = useState<"vertical" | "horizontal">("vertical");

  const inp: React.CSSProperties = {
    background: "#EBEBEB", borderRadius: 10, border: "none", outline: "none",
    color: "#1C1C1E", fontSize: 14, fontFamily: "'Inter', sans-serif",
    width: "100%", padding: "12px 16px", boxSizing: "border-box",
  };

  return (
    <div className="size-full overflow-y-auto" style={{ background: "#F5F5F7" }}>
      <div className="px-4 flex flex-col gap-3" style={{ paddingTop: 24, paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 32px)" }}>
        <button onClick={back} className="self-start active:opacity-70">
          <ChevronLeft size={22} color="#1C1C1E" />
        </button>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 20, fontWeight: 700, color: "#1C1C1E", marginBottom: 8 }}>
          Создать тайтл
        </p>
        <label
          htmlFor="cover-upload"
          style={{ background: "#DDDDE0", borderRadius: 14, border: "2px dashed #B8B8BE", height: 160, cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8 }}
        >
          <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
            <path d="M14 4v14M14 4l-4 4M14 4l4 4" stroke="#A0A0A8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M4 20v2a2 2 0 002 2h16a2 2 0 002-2v-2" stroke="#A0A0A8" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <span style={{ color: "#A0A0A8", fontSize: 12, fontFamily: "'Inter', sans-serif", textAlign: "center", whiteSpace: "pre-line" }}>{"Загрузить страницы\n(первое фото будет обложкой)"}</span>
          <input id="cover-upload" type="file" accept="image/*" style={{ display: "none" }} />
        </label>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Название тайтла" style={inp} />
        <textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Описание" rows={3}
          style={{ ...inp, resize: "none" }} />
        <input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="Теги, жанры" style={inp} />

        {/* Scroll direction toggle */}
        <div>
          <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#8E8E93", marginBottom: 8 }}>
            Направление чтения
          </p>
          <div className="flex" style={{ background: "#EBEBEB", borderRadius: 10, padding: 4, gap: 4 }}>
            {(["vertical", "horizontal"] as const).map((dir) => {
              const active = scrollDir === dir;
              return (
                <button
                  key={dir}
                  onClick={() => setScrollDir(dir)}
                  className="flex-1 flex items-center justify-center gap-2"
                  style={{
                    background: active ? "#121212" : "transparent",
                    borderRadius: 8,
                    padding: "10px 0",
                    border: "none",
                    transition: "background 0.15s",
                  }}
                >
                  {/* Icon */}
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                    {dir === "vertical" ? (
                      <>
                        <rect x="5" y="1" width="8" height="5" rx="1.5" fill={active ? "#fcd773" : "#8E8E93"} />
                        <rect x="5" y="8" width="8" height="5" rx="1.5" fill={active ? "#fcd773" : "#8E8E93"} />
                        <path d="M9 14v3M9 17l-2-2M9 17l2-2" stroke={active ? "#fcd773" : "#8E8E93"} strokeWidth="1.5" strokeLinecap="round" />
                      </>
                    ) : (
                      <>
                        <rect x="1" y="5" width="5" height="8" rx="1.5" fill={active ? "#fcd773" : "#8E8E93"} />
                        <rect x="8" y="5" width="5" height="8" rx="1.5" fill={active ? "#fcd773" : "#8E8E93"} />
                        <path d="M14 9h3M17 9l-2-2M17 9l-2 2" stroke={active ? "#fcd773" : "#8E8E93"} strokeWidth="1.5" strokeLinecap="round" />
                      </>
                    )}
                  </svg>
                  <span style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: 13,
                    fontWeight: 500,
                    color: active ? "#fcd773" : "#8E8E93",
                  }}>
                    {dir === "vertical" ? "Вертикально" : "Горизонтально"}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <button style={{ background: "#fcd773", borderRadius: 10, padding: "14px", border: "2px solid #121212" }}
          className="font-medium text-black text-sm">
          Создать
        </button>
        <button onClick={back} style={{ borderRadius: 10, border: "1.5px solid #DDDDE0", padding: "14px" }}
          className="text-sm font-medium text-gray-600">
          Отмена
        </button>
      </div>
    </div>
  );
}

// ─── Screen: Create Episode (wireframe) ───────────────────────────────────────

function CreateEpisodeScreen({ back }: { back: () => void }) {
  const [num, setNum] = useState("");
  const [name, setName] = useState("");

  const inp: React.CSSProperties = {
    background: "#EBEBEB", borderRadius: 10, border: "none", outline: "none",
    color: "#1C1C1E", fontSize: 14, fontFamily: "'Inter', sans-serif",
    width: "100%", padding: "12px 16px", boxSizing: "border-box",
  };

  return (
    <div className="size-full overflow-y-auto" style={{ background: "#F5F5F7" }}>
      <div className="px-4 flex flex-col gap-3" style={{ paddingTop: 24, paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 32px)" }}>
        <button onClick={back} className="self-start active:opacity-70">
          <ChevronLeft size={22} color="#1C1C1E" />
        </button>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 20, fontWeight: 700, color: "#1C1C1E", marginBottom: 8 }}>
          Создать эпизод
        </p>
        <input value={num} onChange={(e) => setNum(e.target.value)} placeholder="Номер главы" style={inp} />
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Название эпизода" style={inp} />
        <div style={{ background: "#DDDDE0", borderRadius: 12, border: "2px dashed #B8B8BE", height: 80 }}
          className="flex flex-col items-center justify-center">
          <p style={{ color: "#A0A0A8", fontSize: 11 }}>Добавить страницы</p>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[0, 1, 2].map((i) => (
            <div key={i} style={{ background: "#DDDDE0", borderRadius: 8, height: 80 }} />
          ))}
        </div>
        <button style={{ background: "#fcd773", borderRadius: 10, padding: "14px", border: "2px solid #121212" }}
          className="font-medium text-black text-sm">
          Сохранить
        </button>
        <button onClick={back} style={{ borderRadius: 10, border: "1.5px solid #DDDDE0", padding: "14px" }}
          className="text-sm font-medium text-gray-600">
          Отмена
        </button>
      </div>
    </div>
  );
}

// ─── Bottom Nav ───────────────────────────────────────────────────────────────

function BottomNav({ tab, setTab, role }: { tab: Tab; setTab: (t: Tab) => void; role: Role }) {
  const allItems: { id: Tab; icon: React.ReactNode; label: string; authorOnly?: boolean }[] = [
    { id: "main",   icon: <Home size={22} />,       label: "Главная" },
    { id: "search", icon: <Search size={22} />,     label: "Библиотека" },
    { id: "shelf",  icon: <BookMarked size={22} />, label: "Полка" },
    { id: "admin",  icon: <User size={22} />,       label: "Кабинет", authorOnly: true },
  ];
  const items = allItems.filter((it) => !it.authorOnly || role === "author");

  return (
    <div
      className="flex items-center justify-around shrink-0"
      style={{ background: "#1a1a1a", borderTop: "1px solid #2a2a2a", paddingTop: 10, paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 10px)" }}
    >
      {items.map((it) => (
        <button
          key={it.id}
          onClick={() => setTab(it.id)}
          className="flex flex-col items-center gap-0.5 px-3 active:opacity-70"
          style={{ color: tab === it.id ? "#fcd773" : "#555" }}
        >
          {it.icon}
          <span style={{ fontSize: 10, fontWeight: 500, fontFamily: "'Inter', sans-serif" }}>
            {it.label}
          </span>
        </button>
      ))}
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("auth");
  const [role, setRole]     = useState<Role>("reader");
  const [tab, setTab]       = useState<Tab>("main");
  const [stack, setStack]   = useState<Screen[]>([]);

  // Inject viewport-fit=cover so env(safe-area-inset-*) works on iOS
  useEffect(() => {
    let meta = document.querySelector<HTMLMetaElement>('meta[name="viewport"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.name = "viewport";
      document.head.appendChild(meta);
    }
    meta.content = "width=device-width, initial-scale=1, viewport-fit=cover";
  }, []);

  const nav = (s: Screen) => {
    setStack((p) => [...p, screen]);
    setScreen(s);
  };

  const back = () => {
    if (!stack.length) return;
    const prev = stack[stack.length - 1];
    setStack((p) => p.slice(0, -1));
    setScreen(prev);
  };

  const switchTab = (t: Tab) => {
    setTab(t);
    setStack([]);
    const map: Record<Tab, Screen> = { main: "main", search: "search", shelf: "shelf", admin: "admin" };
    setScreen(map[t]);
  };

  const isTabScreen = ["main", "search", "shelf", "admin"].includes(screen);

  const tabOf: Record<Screen, Tab> = {
    auth: "main", main: "main", search: "search", shelf: "shelf", admin: "admin",
    title: "main", read: "main",
    "title-settings": "admin", "edit-chapters": "admin",
    "edit-chapter-images": "admin", "create-title": "admin", "create-episode": "admin",
  };

  const renderScreen = () => {
    switch (screen) {
      case "auth":           return <AuthScreen onLogin={(r) => { setRole(r); setScreen("main"); }} />;
      case "main":           return <MainScreen nav={nav} />;
      case "search":         return <SearchScreen />;
      case "shelf":          return <ShelfScreen nav={nav} />;
      case "title":          return <TitleScreen nav={nav} back={back} />;
      case "read":           return <ReadScreen back={back} />;
      case "admin":          return <AdminScreen nav={nav} />;
      case "title-settings":       return <TitleSettingsScreen nav={nav} back={back} />;
      case "edit-chapters":        return <EditChaptersScreen nav={nav} back={back} />;
      case "edit-chapter-images":  return <EditChapterImagesScreen back={back} />;
      case "create-title":         return <CreateTitleScreen back={back} />;
      case "create-episode":       return <CreateEpisodeScreen back={back} />;
    }
  };

  return (
    <div
      style={{
        width: "100vw",
        height: "100dvh",
        background: "#0a0a0a",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {/* Frame: phone-shaped on desktop, full-screen on mobile.
          borderRadius formula: 0 when viewport ≤ 412px, up to 44px on desktop */}
      <div
        style={{
          width:         "min(412px, 100vw)",
          height:        "min(917px, 100dvh)",
          display:       "flex",
          flexDirection: "column",
          overflow:      "hidden",
          borderRadius:  "clamp(0px, calc((100vw - 412px) * 100), 44px)",
          boxShadow:     "0 40px 100px rgba(0,0,0,0.7)",
          fontFamily:    "'Inter', system-ui, sans-serif",
          background:    "#121212",
        }}
      >
        {/* Top safe area — covers status bar / notch on real devices */}
        <div
          style={{
            height:     "env(safe-area-inset-top, 0px)",
            background: "#121212",
            flexShrink: 0,
          }}
        />

        {/* Screen content */}
        <div className="flex-1 overflow-hidden relative">
          {renderScreen()}
        </div>

        {/* Bottom nav — padding already includes env(safe-area-inset-bottom) */}
        {isTabScreen && (
          <BottomNav tab={tabOf[screen]} setTab={switchTab} role={role} />
        )}
      </div>
    </div>
  );
}
