import svgPaths from "./svg-s5xagun89o";

function Frame1() {
  return <div className="bg-[#888] h-[161px] relative rounded-[24px] shrink-0 w-[122px]" data-name="Frame" />;
}

function Frame2() {
  return <div className="bg-[#888] h-[161px] relative rounded-[24px] shrink-0 w-[120px]" data-name="Frame" />;
}

function Frame3() {
  return <div className="bg-[#888] h-[161px] relative rounded-[24px] shrink-0 w-[122px]" data-name="Frame" />;
}

function Frame() {
  return (
    <div className="absolute content-stretch flex gap-[8px] items-center left-[16px] top-[calc(60%+4.8px)]" data-name="Frame">
      <Frame1 />
      <Frame2 />
      <Frame3 />
    </div>
  );
}

function Frame4() {
  return (
    <div className="absolute h-[16px] left-[16px] top-[calc(40%+156.2px)] w-[69px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Новинки</p>
    </div>
  );
}

function Frame8() {
  return (
    <div className="h-[24px] relative shrink-0 w-[210px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-[calc(50%-105px)] not-italic text-[#121212] text-[24px] top-0 whitespace-nowrap">Заголовок тайтла</p>
    </div>
  );
}

function Frame9() {
  return (
    <div className="h-[16px] relative shrink-0 w-[210px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-[calc(50%-91px)] not-italic text-[#fbf4e5] text-[14px] top-0 whitespace-nowrap">Теги, описывающие тайтл</p>
    </div>
  );
}

function Frame7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] items-center left-0 right-0 top-0" data-name="Frame">
      <Frame8 />
      <Frame9 />
    </div>
  );
}

function Frame6() {
  return (
    <div className="h-[132px] relative shrink-0 w-full" data-name="Frame">
      <Frame7 />
      <div className="absolute bg-[#fcd773] h-[52px] left-[21px] rounded-[8px] top-[80px] w-[169px]">
        <div className="content-stretch flex items-center justify-center overflow-clip px-[43px] py-[14px] relative rounded-[inherit] size-full">
          <p className="[word-break:break-word] font-['Inter:Medium',sans-serif] font-medium leading-none not-italic relative shrink-0 text-[16px] text-black whitespace-nowrap">Читать</p>
        </div>
        <div aria-hidden className="absolute border-2 border-[#121212] border-solid inset-0 pointer-events-none rounded-[8px]" />
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="absolute bg-[#888] content-stretch flex flex-col h-[360px] items-center justify-end left-[16px] overflow-clip px-[85px] py-[40px] rounded-[24px] top-[104px] w-[380px]" data-name="Frame">
      <Frame6 />
    </div>
  );
}

function Frame10() {
  return <div className="absolute bg-[#b2cae9] h-[44px] left-[16px] top-[24px] w-[70px]" data-name="Frame" />;
}

export default function Main() {
  return (
    <div className="bg-[#121212] relative size-full" data-name="main">
      <Frame />
      <Frame4 />
      <Frame5 />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-[calc(90%+3.2px)] size-[44px] top-[calc(10%-45.7px)]" data-name="Vector">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 44 44">
          <path d={svgPaths.p3f990d00} fill="var(--fill-0, #B2CAE9)" id="Vector" />
        </svg>
      </div>
      <Frame10 />
    </div>
  );
}