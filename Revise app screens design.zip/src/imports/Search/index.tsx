function Frame1() {
  return <div className="bg-[#888] justify-self-stretch relative rounded-[24px] self-stretch shrink-0" data-name="Frame" />;
}

function Frame2() {
  return <div className="bg-[#888] justify-self-stretch relative rounded-[24px] self-stretch shrink-0" data-name="Frame" />;
}

function Frame3() {
  return <div className="bg-[#888] justify-self-stretch relative rounded-[24px] self-stretch shrink-0" data-name="Frame" />;
}

function Frame4() {
  return <div className="bg-[#888] justify-self-stretch relative rounded-[24px] self-stretch shrink-0" data-name="Frame" />;
}

function Frame() {
  return (
    <div className="absolute gap-x-[6px] gap-y-[16px] grid grid-cols-[repeat(2,minmax(0,1fr))] grid-rows-[repeat(2,minmax(0,1fr))] h-[252px] left-[16px] top-[calc(40%+51.2px)] w-[380px]" data-name="Frame">
      <Frame1 />
      <Frame2 />
      <Frame3 />
      <Frame4 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="absolute h-[16px] left-[16px] top-[calc(40%+19.2px)] w-[57px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Жанры</p>
    </div>
  );
}

function Frame7() {
  return <div className="bg-[#888] h-[161px] relative rounded-[24px] shrink-0 w-[122px]" data-name="Frame" />;
}

function Frame8() {
  return <div className="bg-[#888] h-[161px] relative rounded-[24px] shrink-0 w-[120px]" data-name="Frame" />;
}

function Frame9() {
  return <div className="bg-[#888] h-[161px] relative rounded-[24px] shrink-0 w-[122px]" data-name="Frame" />;
}

function Frame6() {
  return (
    <div className="absolute content-stretch flex gap-[8px] items-center left-[16px] top-[calc(20%+1.6px)]" data-name="Frame">
      <Frame7 />
      <Frame8 />
      <Frame9 />
    </div>
  );
}

function Frame10() {
  return (
    <div className="absolute h-[16px] left-[16px] top-[153px] w-[99px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Популярные</p>
    </div>
  );
}

function Frame11() {
  return (
    <div className="-translate-x-1/2 absolute bg-[#faf4e7] border-2 border-[#121212] border-solid h-[52px] left-1/2 overflow-clip rounded-[8px] top-[64px] w-[380px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-[22px] not-italic text-[16px] text-[rgba(18,18,18,0.5)] top-[16px] whitespace-nowrap">Поиск</p>
    </div>
  );
}

function Frame12() {
  return (
    <div className="absolute h-[24px] left-[16px] top-[24px] w-[141px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e4] text-[24px] top-0 whitespace-nowrap">Библиотека</p>
    </div>
  );
}

export default function Search() {
  return (
    <div className="bg-[#121212] relative size-full" data-name="search">
      <Frame />
      <Frame5 />
      <Frame6 />
      <Frame10 />
      <Frame11 />
      <Frame12 />
    </div>
  );
}