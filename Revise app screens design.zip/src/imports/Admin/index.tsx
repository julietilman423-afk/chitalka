function Frame2() {
  return (
    <div className="absolute h-[16px] left-[120px] top-[25px] w-[133px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Название тайтла</p>
    </div>
  );
}

function Frame3() {
  return (
    <div className="absolute h-[28px] left-[120px] top-[49px] w-[177px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-[calc(50%-88.5px)] not-italic text-[#fbf4e5] text-[14px] top-0 w-[177px]">Номер последней прочитанной главы</p>
    </div>
  );
}

function Frame1() {
  return (
    <div className="bg-[#121212] h-[118px] relative rounded-[24px] shrink-0 w-full" data-name="Frame">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="-translate-y-1/2 absolute bg-[#98ab69] left-[332px] size-[32px] top-[calc(50%-27px)]" data-name="Rectangle" />
        <div className="-translate-y-1/2 absolute bg-[#888] h-[110px] left-[4px] rounded-[20px] top-1/2 w-[104px]" data-name="Rectangle" />
        <Frame2 />
        <Frame3 />
      </div>
      <div aria-hidden className="absolute border border-[#fcd773] border-solid inset-0 pointer-events-none rounded-[24px]" />
    </div>
  );
}

function Frame5() {
  return (
    <div className="absolute h-[16px] left-[120px] top-[25px] w-[133px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Название тайтла</p>
    </div>
  );
}

function Frame6() {
  return (
    <div className="absolute h-[28px] left-[120px] top-[49px] w-[177px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-[calc(50%-88.5px)] not-italic text-[#fbf4e5] text-[14px] top-0 w-[177px]">Номер последней прочитанной главы</p>
    </div>
  );
}

function Frame4() {
  return (
    <div className="bg-[#121212] h-[118px] relative rounded-[24px] shrink-0 w-full" data-name="Frame">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="-translate-y-1/2 absolute bg-[#888] h-[110px] left-[4px] rounded-[20px] top-1/2 w-[104px]" data-name="Rectangle" />
        <Frame5 />
        <Frame6 />
        <div className="-translate-y-1/2 absolute bg-[#98ab69] left-[332px] size-[32px] top-[calc(50%-27px)]" data-name="Rectangle" />
      </div>
      <div aria-hidden className="absolute border border-[#fcd773] border-solid inset-0 pointer-events-none rounded-[24px]" />
    </div>
  );
}

function Frame8() {
  return (
    <div className="absolute h-[16px] left-[120px] top-[25px] w-[133px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Название тайтла</p>
    </div>
  );
}

function Frame9() {
  return (
    <div className="absolute h-[28px] left-[120px] top-[49px] w-[177px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-[calc(50%-88.5px)] not-italic text-[#fbf4e5] text-[14px] top-0 w-[177px]">Номер последней прочитанной главы</p>
    </div>
  );
}

function Frame7() {
  return (
    <div className="bg-[#121212] h-[118px] relative rounded-[24px] shrink-0 w-full" data-name="Frame">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="-translate-y-1/2 absolute bg-[#888] h-[110px] left-[4px] rounded-[20px] top-1/2 w-[104px]" data-name="Rectangle" />
        <Frame8 />
        <Frame9 />
        <div className="-translate-y-1/2 absolute bg-[#98ab69] left-[332px] size-[32px] top-[calc(50%-27px)]" data-name="Rectangle" />
      </div>
      <div aria-hidden className="absolute border border-[#fcd773] border-solid inset-0 pointer-events-none rounded-[24px]" />
    </div>
  );
}

function Frame11() {
  return (
    <div className="absolute h-[16px] left-[120px] top-[25px] w-[133px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Название тайтла</p>
    </div>
  );
}

function Frame12() {
  return (
    <div className="absolute h-[28px] left-[120px] top-[49px] w-[177px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-[calc(50%-88.5px)] not-italic text-[#fbf4e5] text-[14px] top-0 w-[177px]">Номер последней прочитанной главы</p>
    </div>
  );
}

function Frame10() {
  return (
    <div className="bg-[#121212] h-[118px] relative rounded-[24px] shrink-0 w-full" data-name="Frame">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="-translate-y-1/2 absolute bg-[#888] h-[110px] left-[4px] rounded-[20px] top-1/2 w-[104px]" data-name="Rectangle" />
        <Frame11 />
        <Frame12 />
        <div className="-translate-y-1/2 absolute bg-[#98ab69] left-[332px] size-[32px] top-[calc(50%-27px)]" data-name="Rectangle" />
      </div>
      <div aria-hidden className="absolute border border-[#fcd773] border-solid inset-0 pointer-events-none rounded-[24px]" />
    </div>
  );
}

function Frame() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[16px] items-start left-1/2 top-[116px] w-[380px]" data-name="Frame">
      <Frame1 />
      <Frame4 />
      <Frame7 />
      <Frame10 />
    </div>
  );
}

function Frame13() {
  return (
    <div className="absolute h-[16px] left-[16px] top-[60px] w-[173px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Загруженные тайтлы</p>
    </div>
  );
}

function Frame14() {
  return (
    <div className="absolute h-[24px] left-[16px] top-[24px] w-[331px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e4] text-[24px] top-0 whitespace-nowrap">Кабинет автора</p>
    </div>
  );
}

export default function Admin() {
  return (
    <div className="bg-[#121212] relative size-full" data-name="admin">
      <div className="-translate-x-1/2 absolute bg-[#fcd773] h-[52px] left-[calc(50%+2.5px)] rounded-[8px] top-[calc(60%+101.8px)] w-[377px]">
        <div className="content-stretch flex items-center justify-center overflow-clip px-[42px] py-[14px] relative rounded-[inherit] size-full">
          <p className="[word-break:break-word] font-['Inter:Medium',sans-serif] font-medium leading-none not-italic relative shrink-0 text-[16px] text-black whitespace-nowrap">Добавить тайтл</p>
        </div>
        <div aria-hidden className="absolute border-2 border-[#121212] border-solid inset-0 pointer-events-none rounded-[8px]" />
      </div>
      <Frame />
      <Frame13 />
      <Frame14 />
    </div>
  );
}