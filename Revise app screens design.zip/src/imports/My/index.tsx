function Frame2() {
  return (
    <div className="absolute h-[16px] left-[120px] top-[25px] w-[133px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Название тайтла</p>
    </div>
  );
}

function Frame3() {
  return (
    <div className="absolute h-[28px] left-[120px] top-[49px] w-[177px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-[calc(50%-88.5px)] not-italic text-[#fbf4e5] text-[14px] top-0 w-[177px]">Номер последней прочитанной главы</p>
    </div>
  );
}

function Frame1() {
  return (
    <div className="bg-[#121212] h-[118px] relative rounded-[24px] shrink-0 w-full" data-name="Frame">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="-translate-y-1/2 absolute bg-[#fcb7d9] h-[38px] left-[324px] top-1/2 w-[32px]" data-name="Rectangle" />
        <div className="-translate-y-1/2 absolute bg-[#888] h-[110px] left-[4px] rounded-[20px] top-1/2 w-[104px]" data-name="Rectangle" />
        <Frame2 />
        <Frame3 />
      </div>
      <div aria-hidden className="absolute border border-[#fcd773] border-solid inset-0 pointer-events-none rounded-[24px]" />
    </div>
  );
}

function Frame5() {
  return (
    <div className="absolute h-[16px] left-[120px] top-[25px] w-[133px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Название тайтла</p>
    </div>
  );
}

function Frame6() {
  return (
    <div className="absolute h-[28px] left-[120px] top-[49px] w-[177px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-[calc(50%-88.5px)] not-italic text-[#fbf4e5] text-[14px] top-0 w-[177px]">Номер последней прочитанной главы</p>
    </div>
  );
}

function Frame4() {
  return (
    <div className="bg-[#121212] h-[118px] relative rounded-[24px] shrink-0 w-full" data-name="Frame">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="-translate-y-1/2 absolute bg-[#fcb7d9] h-[38px] left-[324px] top-1/2 w-[32px]" data-name="Rectangle" />
        <div className="-translate-y-1/2 absolute bg-[#888] h-[110px] left-[4px] rounded-[20px] top-1/2 w-[104px]" data-name="Rectangle" />
        <Frame5 />
        <Frame6 />
      </div>
      <div aria-hidden className="absolute border border-[#fcd773] border-solid inset-0 pointer-events-none rounded-[24px]" />
    </div>
  );
}

function Frame8() {
  return (
    <div className="absolute h-[16px] left-[120px] top-[25px] w-[133px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Название тайтла</p>
    </div>
  );
}

function Frame9() {
  return (
    <div className="absolute h-[28px] left-[120px] top-[49px] w-[177px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-[calc(50%-88.5px)] not-italic text-[#fbf4e5] text-[14px] top-0 w-[177px]">Номер последней прочитанной главы</p>
    </div>
  );
}

function Frame7() {
  return (
    <div className="bg-[#121212] h-[118px] relative rounded-[24px] shrink-0 w-full" data-name="Frame">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="-translate-y-1/2 absolute bg-[#fcb7d9] h-[38px] left-[324px] top-1/2 w-[32px]" data-name="Rectangle" />
        <div className="-translate-y-1/2 absolute bg-[#888] h-[110px] left-[4px] rounded-[20px] top-1/2 w-[104px]" data-name="Rectangle" />
        <Frame8 />
        <Frame9 />
      </div>
      <div aria-hidden className="absolute border border-[#fcd773] border-solid inset-0 pointer-events-none rounded-[24px]" />
    </div>
  );
}

function Frame11() {
  return (
    <div className="absolute h-[16px] left-[120px] top-[25px] w-[133px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e5] text-[16px] top-0 whitespace-nowrap">Название тайтла</p>
    </div>
  );
}

function Frame12() {
  return (
    <div className="absolute h-[28px] left-[120px] top-[49px] w-[177px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-[calc(50%-88.5px)] not-italic text-[#fbf4e5] text-[14px] top-0 w-[177px]">Номер последней прочитанной главы</p>
    </div>
  );
}

function Frame10() {
  return (
    <div className="bg-[#121212] h-[118px] relative rounded-[24px] shrink-0 w-full" data-name="Frame">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="-translate-y-1/2 absolute bg-[#fcb7d9] h-[38px] left-[324px] top-1/2 w-[32px]" data-name="Rectangle" />
        <div className="-translate-y-1/2 absolute bg-[#888] h-[110px] left-[4px] rounded-[20px] top-1/2 w-[104px]" data-name="Rectangle" />
        <Frame11 />
        <Frame12 />
      </div>
      <div aria-hidden className="absolute border border-[#fcd773] border-solid inset-0 pointer-events-none rounded-[24px]" />
    </div>
  );
}

function Frame() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] items-start left-[16px] top-[97px] w-[380px]" data-name="Frame">
      <Frame1 />
      <Frame4 />
      <Frame7 />
      <Frame10 />
    </div>
  );
}

function Frame13() {
  return (
    <div className="absolute h-[24px] left-[16px] top-[33px] w-[141px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e4] text-[24px] top-[-9px] whitespace-nowrap">Моя полка</p>
    </div>
  );
}

export default function My() {
  return (
    <div className="bg-[#121212] relative size-full" data-name="my">
      <Frame />
      <Frame13 />
    </div>
  );
}