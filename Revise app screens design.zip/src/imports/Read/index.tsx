function Frame() {
  return (
    <div className="absolute bg-[#121212] h-[917px] left-0 overflow-clip top-0 w-[412px]" data-name="Frame">
      <div className="-translate-y-1/2 absolute bg-[#fcb7d9] h-[38px] left-[364px] top-[calc(50%+367.5px)] w-[32px]" data-name="Rectangle" />
      <div className="-translate-y-1/2 absolute bg-[#fcb7d9] h-[38px] left-[321px] top-[calc(50%+367.5px)] w-[32px]" data-name="Rectangle" />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute h-[24px] left-[16px] top-[24px] w-[183px]" data-name="Frame">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-none left-0 not-italic text-[#fbf4e4] text-[24px] top-0 whitespace-nowrap">Номер эпизода</p>
    </div>
  );
}

export default function Read() {
  return (
    <div className="bg-[#121212] relative size-full" data-name="read">
      <Frame />
      <Frame1 />
    </div>
  );
}